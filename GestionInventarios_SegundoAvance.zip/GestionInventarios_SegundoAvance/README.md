# Aplicación de Gestión de Inventarios — Segundo avance

**Universidad CENFOTEC**  
**Curso:** SOFT-10 — Estructuras de Datos  
**Sección:** SCV3 · **Periodo:** C3-2026

## Descripción

Aplicación Java de consola para simular una tienda en línea. Administra el inventario mediante un árbol binario de búsqueda, mantiene los carritos de compra en listas enlazadas y atiende clientes mediante una cola de prioridad.

## Requisitos

- JDK 17 o superior.
- No utiliza bibliotecas externas.
- Puede abrirse como proyecto Java en IntelliJ IDEA, Eclipse o VS Code.

## Estructura

```text
GestionInventarios_SegundoAvance/
├── src/
│   ├── Producto.java
│   ├── ItemCarrito.java
│   ├── NodoProducto.java
│   ├── ListaProductos.java
│   ├── Cliente.java
│   ├── NodoArbolProducto.java
│   ├── ArbolProductos.java
│   ├── NodoCliente.java
│   ├── ColaClientes.java
│   ├── Tienda.java
│   ├── Main.java
│   └── PruebasBasicas.java
├── README.md
├── .gitignore
└── compilar_y_ejecutar.bat
```

## Estructuras de datos implementadas

1. **ArbolProductos:** árbol binario de búsqueda ordenado por nombre. Incluye inserción, búsqueda, eliminación y recorrido inorden.
2. **ListaProductos:** lista enlazada simple para el carrito individual de cada cliente.
3. **ColaClientes:** cola de prioridad enlazada. Atiende primero prioridad 3, luego 2 y luego 1. Los clientes con la misma prioridad conservan el orden de llegada.
4. **Tienda:** integra el árbol de inventario y la cola de clientes.

## Reglas de funcionamiento

- Prioridad 1: cliente básico.
- Prioridad 2: cliente afiliado.
- Prioridad 3: cliente premium.
- No se permiten nombres de producto duplicados en el árbol.
- El nombre del producto se utiliza como llave, sin distinguir mayúsculas y minúsculas.
- Las unidades se reservan del inventario al agregarse al carrito. Esto evita que dos carritos reserven las mismas existencias.
- Si un producto se agrega varias veces al mismo carrito, se acumula la cantidad en una sola línea.
- La factura muestra los productos, cantidades, subtotales y total acumulado.

## Compilar y ejecutar desde terminal

Desde la carpeta raíz del proyecto:

```bash
javac -encoding UTF-8 -d out src/*.java
java -cp out Main
```

En Windows también puede ejecutar `compilar_y_ejecutar.bat`.

## Ejecutar pruebas básicas

```bash
javac -encoding UTF-8 -d out src/*.java
java -cp out PruebasBasicas
```

Las pruebas verifican inserción, búsqueda y eliminación del árbol; prioridades y desempate FIFO; reserva de inventario; carrito y total de factura.

## Subir a GitHub

1. Cree un repositorio vacío en GitHub o abra el repositorio de su equipo.
2. Copie el contenido de esta carpeta al repositorio.
3. Desde la raíz del proyecto ejecute:

```bash
git add .
git commit -m "Implementa segundo avance de gestion de inventarios"
git push
```

Si se trata de un repositorio nuevo:

```bash
git init
git branch -M main
git add .
git commit -m "Segundo avance: aplicación de gestión de inventarios"
git remote add origin https://github.com/USUARIO/REPOSITORIO.git
git push -u origin main
```

Reemplace `USUARIO/REPOSITORIO` por los datos reales del repositorio del grupo.

## Correspondencia con la consigna

- Clases Cliente, ColaClientes, Tienda y ArbolProductos.
- Inventario de productos almacenado en un árbol binario de búsqueda.
- Cola de prioridad con prioridades 1, 2 y 3 y desempate por orden de llegada.
- Carrito individual por cliente.
- Menú de consola dentro de Main y rutina main().
- Inserción y consulta de productos, registro de clientes, atención y factura.
