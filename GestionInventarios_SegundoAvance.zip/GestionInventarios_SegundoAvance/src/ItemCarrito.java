import java.math.BigDecimal;

/** Guarda el producto seleccionado y la cantidad solicitada por el cliente. */
public class ItemCarrito {
    private final Producto producto;
    private int cantidad;

    public ItemCarrito(Producto producto, int cantidad) {
        if (producto == null || cantidad <= 0) {
            throw new IllegalArgumentException("Producto y cantidad deben ser válidos.");
        }
        this.producto = producto;
        this.cantidad = cantidad;
    }

    public Producto getProducto() { return producto; }
    public int getCantidad() { return cantidad; }
    public void agregarCantidad(int unidades) {
        if (unidades <= 0) throw new IllegalArgumentException("La cantidad debe ser positiva.");
        cantidad += unidades;
    }
    public BigDecimal getSubtotal() {
        return producto.getPrecio().multiply(BigDecimal.valueOf(cantidad));
    }
}
