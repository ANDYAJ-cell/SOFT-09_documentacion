/** Nodo enlazado utilizado por la cola de prioridad de clientes. */
public class NodoCliente {
    private final Cliente cliente;
    private NodoCliente siguiente;

    public NodoCliente(Cliente cliente) { this.cliente = cliente; }
    public Cliente getCliente() { return cliente; }
    public NodoCliente getSiguiente() { return siguiente; }
    public void setSiguiente(NodoCliente siguiente) { this.siguiente = siguiente; }
}
