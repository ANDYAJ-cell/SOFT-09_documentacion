/**
 * Representa a un cliente y su carrito personal.
 * Prioridades: 1 básico, 2 afiliado y 3 premium.
 */
public class Cliente {
    private final String nombre;
    private final String identificacion;
    private final int prioridad;
    private final ListaProductos carrito;

    public Cliente(String nombre, String identificacion, int prioridad) {
        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("El nombre del cliente es obligatorio.");
        }
        if (identificacion == null || identificacion.isBlank()) {
            throw new IllegalArgumentException("La identificación es obligatoria.");
        }
        if (prioridad < 1 || prioridad > 3) {
            throw new IllegalArgumentException("La prioridad debe estar entre 1 y 3.");
        }
        this.nombre = nombre.trim();
        this.identificacion = identificacion.trim();
        this.prioridad = prioridad;
        this.carrito = new ListaProductos();
    }

    public String getNombre() { return nombre; }
    public String getIdentificacion() { return identificacion; }
    public int getPrioridad() { return prioridad; }
    public ListaProductos getCarrito() { return carrito; }

    public String getTipoCliente() {
        return switch (prioridad) {
            case 3 -> "Premium";
            case 2 -> "Afiliado";
            default -> "Básico";
        };
    }

    @Override
    public String toString() {
        return nombre + " (" + identificacion + ") - " + getTipoCliente()
                + " [prioridad " + prioridad + "]";
    }
}
