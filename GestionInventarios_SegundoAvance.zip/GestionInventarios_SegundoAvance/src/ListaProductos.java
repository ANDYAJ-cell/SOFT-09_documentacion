import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Lista enlazada simple que representa el carrito personal de un cliente.
 * Cada nodo contiene un ItemCarrito para separar la cantidad comprada
 * de las existencias del Producto.
 */
public class ListaProductos {
    private NodoProducto primero;
    private int tamanio;

    public void agregarProducto(Producto producto, int cantidad) {
        if (producto == null || cantidad <= 0) {
            throw new IllegalArgumentException("Producto y cantidad deben ser válidos.");
        }
        NodoProducto actual = primero;
        while (actual != null) {
            if (actual.getItem().getProducto().getNombre().equalsIgnoreCase(producto.getNombre())) {
                actual.getItem().agregarCantidad(cantidad);
                return;
            }
            actual = actual.getSiguiente();
        }
        NodoProducto nuevo = new NodoProducto(new ItemCarrito(producto, cantidad));
        if (primero == null) {
            primero = nuevo;
        } else {
            actual = primero;
            while (actual.getSiguiente() != null) actual = actual.getSiguiente();
            actual.setSiguiente(nuevo);
        }
        tamanio++;
    }

    public boolean estaVacia() { return primero == null; }
    public int getTamanio() { return tamanio; }

    public List<ItemCarrito> obtenerItems() {
        List<ItemCarrito> items = new ArrayList<>();
        NodoProducto actual = primero;
        while (actual != null) {
            items.add(actual.getItem());
            actual = actual.getSiguiente();
        }
        return List.copyOf(items);
    }

    public BigDecimal calcularTotal() {
        BigDecimal total = BigDecimal.ZERO;
        NodoProducto actual = primero;
        while (actual != null) {
            total = total.add(actual.getItem().getSubtotal());
            actual = actual.getSiguiente();
        }
        return total;
    }

    public void imprimirCarrito() {
        if (estaVacia()) {
            System.out.println("El carrito está vacío.");
            return;
        }
        System.out.println("PRODUCTOS DEL CARRITO");
        NodoProducto actual = primero;
        while (actual != null) {
            ItemCarrito item = actual.getItem();
            System.out.printf("- %s x %d = ₡%s%n",
                    item.getProducto().getNombre(), item.getCantidad(),
                    item.getSubtotal().toPlainString());
            actual = actual.getSiguiente();
        }
        System.out.println("Total: ₡" + calcularTotal().toPlainString());
    }
}
