/** Nodo del árbol binario de búsqueda de productos. */
public class NodoArbolProducto {
    private final Producto producto;
    private NodoArbolProducto izquierdo;
    private NodoArbolProducto derecho;

    public NodoArbolProducto(Producto producto) { this.producto = producto; }
    public Producto getProducto() { return producto; }
    public NodoArbolProducto getIzquierdo() { return izquierdo; }
    public NodoArbolProducto getDerecho() { return derecho; }
    public void setIzquierdo(NodoArbolProducto izquierdo) { this.izquierdo = izquierdo; }
    public void setDerecho(NodoArbolProducto derecho) { this.derecho = derecho; }
}
