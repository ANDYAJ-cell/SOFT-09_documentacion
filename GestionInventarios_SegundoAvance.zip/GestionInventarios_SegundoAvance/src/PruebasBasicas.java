import java.math.BigDecimal;

/**
 * Pruebas manuales ejecutables sin bibliotecas externas.
 * Ejecute: java PruebasBasicas
 */
public class PruebasBasicas {
    public static void main(String[] args) {
        probarArbol();
        probarColaPrioridad();
        probarCarritoYFactura();
        System.out.println("\nTodas las pruebas básicas finalizaron correctamente.");
    }

    private static void probarArbol() {
        ArbolProductos arbol = new ArbolProductos();
        Producto b = producto("B");
        Producto a = producto("A");
        Producto c = producto("C");
        comprobar(arbol.insertar(b), "Insertar B");
        comprobar(arbol.insertar(a), "Insertar A");
        comprobar(arbol.insertar(c), "Insertar C");
        comprobar(!arbol.insertar(producto("A")), "Evitar duplicados");
        comprobar(arbol.buscar("b") == b, "Búsqueda sin distinguir mayúsculas");
        comprobar(arbol.eliminar("B"), "Eliminar nodo con dos hijos");
        comprobar(arbol.buscar("B") == null && arbol.getTamanio() == 2, "Estado luego de eliminar");
    }

    private static void probarColaPrioridad() {
        ColaClientes cola = new ColaClientes();
        Cliente basico = new Cliente("Básico", "1", 1);
        Cliente premium1 = new Cliente("Premium 1", "2", 3);
        Cliente premium2 = new Cliente("Premium 2", "3", 3);
        Cliente afiliado = new Cliente("Afiliado", "4", 2);
        cola.encolar(basico);
        cola.encolar(premium1);
        cola.encolar(premium2);
        cola.encolar(afiliado);
        comprobar(cola.desencolar() == premium1, "Prioridad 3 primero");
        comprobar(cola.desencolar() == premium2, "FIFO en empate");
        comprobar(cola.desencolar() == afiliado, "Prioridad 2 antes que 1");
        comprobar(cola.desencolar() == basico, "Prioridad 1 al final");
    }

    private static void probarCarritoYFactura() {
        Tienda tienda = new Tienda();
        Producto arroz = new Producto("Arroz", new BigDecimal("1000"), "Granos", "", 10);
        comprobar(tienda.agregarProducto(arroz), "Agregar producto a tienda");
        Cliente cliente = new Cliente("Prueba", "123", 3);
        comprobar(tienda.agregarAlCarrito(cliente, "Arroz", 2), "Agregar al carrito");
        comprobar(arroz.getCantidad() == 8, "Reservar existencias");
        comprobar(tienda.registrarCliente(cliente), "Registrar cliente");
        String factura = tienda.atenderSiguienteCliente();
        comprobar(factura.contains("TOTAL A PAGAR: ₡2000"), "Total de factura");
        comprobar(tienda.getColaClientes().estaVacia(), "Cola vacía luego de atender");
    }

    private static Producto producto(String nombre) {
        return new Producto(nombre, BigDecimal.ONE, "Prueba", "", 5);
    }

    private static void comprobar(boolean condicion, String prueba) {
        if (!condicion) throw new AssertionError("Falló: " + prueba);
        System.out.println("[OK] " + prueba);
    }
}
