/** Nodo de la lista enlazada del carrito de compras. */
public class NodoProducto {
    private final ItemCarrito item;
    private NodoProducto siguiente;

    public NodoProducto(ItemCarrito item) {
        this.item = item;
    }
    public ItemCarrito getItem() { return item; }
    public NodoProducto getSiguiente() { return siguiente; }
    public void setSiguiente(NodoProducto siguiente) { this.siguiente = siguiente; }
}
