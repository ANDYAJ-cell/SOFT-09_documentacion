import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Representa un producto disponible en el inventario de la tienda.
 * El nombre se utiliza como llave del ArbolProductos.
 */
public class Producto {
    private final String nombre;
    private BigDecimal precio;
    private String categoria;
    private String fechaVencimiento;
    private int cantidad;
    private final ArrayList<String> listImagenes;

    public Producto(String nombre, BigDecimal precio, String categoria,
                    String fechaVencimiento, int cantidad) {
        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("El nombre del producto es obligatorio.");
        }
        if (precio == null || precio.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo.");
        }
        if (cantidad < 0) {
            throw new IllegalArgumentException("La cantidad no puede ser negativa.");
        }
        this.nombre = nombre.trim();
        this.precio = precio;
        this.categoria = categoria == null ? "" : categoria.trim();
        this.fechaVencimiento = fechaVencimiento == null ? "" : fechaVencimiento.trim();
        this.cantidad = cantidad;
        this.listImagenes = new ArrayList<>();
    }

    public String getNombre() { return nombre; }
    public BigDecimal getPrecio() { return precio; }
    public String getCategoria() { return categoria; }
    public String getFechaVencimiento() { return fechaVencimiento; }
    public int getCantidad() { return cantidad; }
    public List<String> getListImagenes() { return List.copyOf(listImagenes); }

    public void setPrecio(BigDecimal precio) {
        if (precio == null || precio.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo.");
        }
        this.precio = precio;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria == null ? "" : categoria.trim();
    }

    public void setFechaVencimiento(String fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento == null ? "" : fechaVencimiento.trim();
    }

    public void agregarImagen(String ruta) {
        if (ruta != null && !ruta.isBlank()) listImagenes.add(ruta.trim());
    }

    /** Reserva unidades para un carrito o descuenta unidades del inventario. */
    public boolean reservar(int unidades) {
        if (unidades <= 0 || unidades > cantidad) return false;
        cantidad -= unidades;
        return true;
    }

    public void reponer(int unidades) {
        if (unidades <= 0) throw new IllegalArgumentException("La reposición debe ser positiva.");
        cantidad += unidades;
    }

    @Override
    public String toString() {
        return String.format("%s | Categoría: %s | Precio: ₡%s | Existencias: %d%s",
                nombre, categoria, precio.toPlainString(), cantidad,
                fechaVencimiento.isBlank() ? "" : " | Vence: " + fechaVencimiento);
    }
}
