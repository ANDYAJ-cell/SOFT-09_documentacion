import java.util.ArrayList;
import java.util.List;

/**
 * Árbol binario de búsqueda ordenado alfabéticamente por nombre de producto.
 */
public class ArbolProductos {
    private NodoArbolProducto raiz;
    private int tamanio;

    public boolean insertar(Producto producto) {
        if (producto == null) return false;
        if (buscar(producto.getNombre()) != null) return false;
        raiz = insertarRec(raiz, producto);
        tamanio++;
        return true;
    }

    private NodoArbolProducto insertarRec(NodoArbolProducto actual, Producto producto) {
        if (actual == null) return new NodoArbolProducto(producto);
        int comparacion = producto.getNombre().compareToIgnoreCase(actual.getProducto().getNombre());
        if (comparacion < 0) actual.setIzquierdo(insertarRec(actual.getIzquierdo(), producto));
        else if (comparacion > 0) actual.setDerecho(insertarRec(actual.getDerecho(), producto));
        return actual;
    }

    public Producto buscar(String nombre) {
        if (nombre == null) return null;
        NodoArbolProducto actual = raiz;
        while (actual != null) {
            int comparacion = nombre.trim().compareToIgnoreCase(actual.getProducto().getNombre());
            if (comparacion == 0) return actual.getProducto();
            actual = comparacion < 0 ? actual.getIzquierdo() : actual.getDerecho();
        }
        return null;
    }

    public boolean eliminar(String nombre) {
        if (buscar(nombre) == null) return false;
        raiz = eliminarRec(raiz, nombre.trim());
        tamanio--;
        return true;
    }

    private NodoArbolProducto eliminarRec(NodoArbolProducto nodo, String nombre) {
        if (nodo == null) return null;
        int cmp = nombre.compareToIgnoreCase(nodo.getProducto().getNombre());
        if (cmp < 0) nodo.setIzquierdo(eliminarRec(nodo.getIzquierdo(), nombre));
        else if (cmp > 0) nodo.setDerecho(eliminarRec(nodo.getDerecho(), nombre));
        else {
            if (nodo.getIzquierdo() == null) return nodo.getDerecho();
            if (nodo.getDerecho() == null) return nodo.getIzquierdo();
            NodoArbolProducto sucesor = minimo(nodo.getDerecho());
            NodoArbolProducto reemplazo = new NodoArbolProducto(sucesor.getProducto());
            reemplazo.setIzquierdo(nodo.getIzquierdo());
            reemplazo.setDerecho(eliminarRec(nodo.getDerecho(), sucesor.getProducto().getNombre()));
            return reemplazo;
        }
        return nodo;
    }

    private NodoArbolProducto minimo(NodoArbolProducto nodo) {
        while (nodo.getIzquierdo() != null) nodo = nodo.getIzquierdo();
        return nodo;
    }

    public List<Producto> listarOrdenados() {
        List<Producto> productos = new ArrayList<>();
        inOrden(raiz, productos);
        return productos;
    }

    private void inOrden(NodoArbolProducto nodo, List<Producto> salida) {
        if (nodo == null) return;
        inOrden(nodo.getIzquierdo(), salida);
        salida.add(nodo.getProducto());
        inOrden(nodo.getDerecho(), salida);
    }

    public boolean estaVacio() { return raiz == null; }
    public int getTamanio() { return tamanio; }
}
