import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Integra el inventario (árbol) y la cola de atención de clientes.
 * Las unidades se reservan al agregarse al carrito para evitar vender
 * existencias que ya fueron seleccionadas por otro cliente.
 */
public class Tienda {
    private final ArbolProductos inventario;
    private final ColaClientes colaClientes;

    public Tienda() {
        inventario = new ArbolProductos();
        colaClientes = new ColaClientes();
    }

    public ArbolProductos getInventario() { return inventario; }
    public ColaClientes getColaClientes() { return colaClientes; }

    public boolean agregarProducto(Producto producto) {
        return inventario.insertar(producto);
    }

    public boolean agregarAlCarrito(Cliente cliente, String nombreProducto, int cantidad) {
        if (cliente == null || cantidad <= 0) return false;
        Producto producto = inventario.buscar(nombreProducto);
        if (producto == null || !producto.reservar(cantidad)) return false;
        cliente.getCarrito().agregarProducto(producto, cantidad);
        return true;
    }

    public boolean registrarCliente(Cliente cliente) {
        if (cliente == null || cliente.getCarrito().estaVacia()) return false;
        colaClientes.encolar(cliente);
        return true;
    }

    /** Atiende al cliente de mayor prioridad y devuelve la factura como texto. */
    public String atenderSiguienteCliente() {
        Cliente cliente = colaClientes.desencolar();
        if (cliente == null) return "No hay clientes pendientes de atención.";

        StringBuilder factura = new StringBuilder();
        factura.append("\n============================================\n");
        factura.append("             FACTURA DE COMPRA\n");
        factura.append("============================================\n");
        factura.append("Fecha: ").append(LocalDateTime.now().format(
                DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))).append('\n');
        factura.append("Cliente: ").append(cliente.getNombre()).append('\n');
        factura.append("Identificación: ").append(cliente.getIdentificacion()).append('\n');
        factura.append("Tipo: ").append(cliente.getTipoCliente()).append('\n');
        factura.append("--------------------------------------------\n");
        factura.append(String.format("%-22s %5s %12s%n", "Producto", "Cant.", "Subtotal"));
        factura.append("--------------------------------------------\n");

        for (ItemCarrito item : cliente.getCarrito().obtenerItems()) {
            String nombre = item.getProducto().getNombre();
            if (nombre.length() > 22) nombre = nombre.substring(0, 19) + "...";
            factura.append(String.format("%-22s %5d ₡%10s%n",
                    nombre, item.getCantidad(), item.getSubtotal().toPlainString()));
        }

        BigDecimal total = cliente.getCarrito().calcularTotal();
        factura.append("--------------------------------------------\n");
        factura.append("TOTAL A PAGAR: ₡").append(total.toPlainString()).append('\n');
        factura.append("============================================\n");
        factura.append("Gracias por su compra.\n");
        return factura.toString();
    }
}
