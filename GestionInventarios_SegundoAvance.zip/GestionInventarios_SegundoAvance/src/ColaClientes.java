import java.util.ArrayList;
import java.util.List;

/**
 * Cola de prioridad enlazada. Prioridad mayor primero; ante empate,
 * se conserva el orden de llegada (FIFO).
 */
public class ColaClientes {
    private NodoCliente frente;
    private int tamanio;

    public void encolar(Cliente cliente) {
        if (cliente == null) throw new IllegalArgumentException("El cliente no puede ser nulo.");
        NodoCliente nuevo = new NodoCliente(cliente);

        if (frente == null || cliente.getPrioridad() > frente.getCliente().getPrioridad()) {
            nuevo.setSiguiente(frente);
            frente = nuevo;
        } else {
            NodoCliente actual = frente;
            // Se avanza también sobre prioridades iguales para respetar FIFO.
            while (actual.getSiguiente() != null
                    && actual.getSiguiente().getCliente().getPrioridad() >= cliente.getPrioridad()) {
                actual = actual.getSiguiente();
            }
            nuevo.setSiguiente(actual.getSiguiente());
            actual.setSiguiente(nuevo);
        }
        tamanio++;
    }

    public Cliente desencolar() {
        if (frente == null) return null;
        Cliente atendido = frente.getCliente();
        frente = frente.getSiguiente();
        tamanio--;
        return atendido;
    }

    public Cliente verSiguiente() {
        return frente == null ? null : frente.getCliente();
    }

    public boolean estaVacia() { return frente == null; }
    public int getTamanio() { return tamanio; }

    public List<Cliente> listarEnOrden() {
        List<Cliente> clientes = new ArrayList<>();
        NodoCliente actual = frente;
        while (actual != null) {
            clientes.add(actual.getCliente());
            actual = actual.getSiguiente();
        }
        return List.copyOf(clientes);
    }
}
