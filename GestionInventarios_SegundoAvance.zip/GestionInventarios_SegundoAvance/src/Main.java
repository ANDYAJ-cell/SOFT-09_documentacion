import java.math.BigDecimal;
import java.util.List;
import java.util.Scanner;

/** Punto de entrada y menú de consola de la aplicación. */
public class Main {
    private static final Scanner SCANNER = new Scanner(System.in);
    private static final Tienda TIENDA = new Tienda();

    public static void main(String[] args) {
        cargarDatosDeEjemplo();
        menu();
    }

    /** Menú principal solicitado en la consigna. */
    public static void menu() {
        boolean continuar = true;
        System.out.println("==============================================");
        System.out.println("       SISTEMA DE GESTIÓN DE INVENTARIOS");
        System.out.println("==============================================");

        while (continuar) {
            System.out.println("\n1. Agregar producto al inventario");
            System.out.println("2. Mostrar inventario");
            System.out.println("3. Buscar producto");
            System.out.println("4. Registrar cliente y llenar carrito");
            System.out.println("5. Atender siguiente cliente y generar factura");
            System.out.println("6. Mostrar cola de clientes");
            System.out.println("0. Salir");
            int opcion = leerEntero("Seleccione una opción: ");

            switch (opcion) {
                case 1 -> agregarProducto();
                case 2 -> mostrarInventario();
                case 3 -> buscarProducto();
                case 4 -> registrarCliente();
                case 5 -> System.out.println(TIENDA.atenderSiguienteCliente());
                case 6 -> mostrarCola();
                case 0 -> {
                    continuar = false;
                    System.out.println("Gracias por utilizar el sistema.");
                }
                default -> System.out.println("Opción inválida. Intente nuevamente.");
            }
        }
    }

    private static void agregarProducto() {
        System.out.println("\n--- REGISTRO DE PRODUCTO ---");
        String nombre = leerTexto("Nombre: ");
        BigDecimal precio = leerDecimal("Precio: ");
        String categoria = leerTexto("Categoría: ");
        String vencimiento = leerTexto("Fecha de vencimiento (opcional): ");
        int cantidad = leerEnteroPositivo("Cantidad inicial: ");
        try {
            Producto producto = new Producto(nombre, precio, categoria, vencimiento, cantidad);
            if (TIENDA.agregarProducto(producto)) {
                System.out.println("Producto agregado correctamente.");
            } else {
                System.out.println("Ya existe un producto con ese nombre.");
            }
        } catch (IllegalArgumentException ex) {
            System.out.println("No se pudo agregar: " + ex.getMessage());
        }
    }

    private static void mostrarInventario() {
        List<Producto> productos = TIENDA.getInventario().listarOrdenados();
        System.out.println("\n--- INVENTARIO (" + productos.size() + " productos) ---");
        if (productos.isEmpty()) {
            System.out.println("No hay productos registrados.");
            return;
        }
        for (Producto producto : productos) System.out.println(producto);
    }

    private static void buscarProducto() {
        String nombre = leerTexto("Nombre del producto: ");
        Producto producto = TIENDA.getInventario().buscar(nombre);
        System.out.println(producto == null ? "Producto no encontrado." : producto);
    }

    private static void registrarCliente() {
        System.out.println("\n--- REGISTRO DE CLIENTE ---");
        String nombre = leerTexto("Nombre: ");
        String identificacion = leerTexto("Identificación: ");
        System.out.println("Tipo de cliente: 1. Básico  2. Afiliado  3. Premium");
        int prioridad = leerEnteroRango("Seleccione el tipo: ", 1, 3);

        Cliente cliente;
        try {
            cliente = new Cliente(nombre, identificacion, prioridad);
        } catch (IllegalArgumentException ex) {
            System.out.println("Datos inválidos: " + ex.getMessage());
            return;
        }

        boolean agregarMas = true;
        while (agregarMas) {
            mostrarInventario();
            String nombreProducto = leerTexto("Producto que desea agregar al carrito: ");
            int cantidad = leerEnteroPositivo("Cantidad: ");
            if (TIENDA.agregarAlCarrito(cliente, nombreProducto, cantidad)) {
                System.out.println("Producto agregado y unidades reservadas.");
            } else {
                System.out.println("No se pudo agregar. Verifique el nombre y las existencias.");
            }
            agregarMas = leerSiNo("¿Desea agregar otro producto? (s/n): ");
        }

        if (TIENDA.registrarCliente(cliente)) {
            System.out.println("Cliente agregado a la cola de atención.");
            cliente.getCarrito().imprimirCarrito();
        } else {
            System.out.println("El cliente no fue agregado porque su carrito está vacío.");
        }
    }

    private static void mostrarCola() {
        List<Cliente> clientes = TIENDA.getColaClientes().listarEnOrden();
        System.out.println("\n--- COLA DE CLIENTES ---");
        if (clientes.isEmpty()) {
            System.out.println("No hay clientes pendientes.");
            return;
        }
        int posicion = 1;
        for (Cliente cliente : clientes) {
            System.out.println(posicion++ + ". " + cliente);
        }
    }

    private static void cargarDatosDeEjemplo() {
        TIENDA.agregarProducto(new Producto("Arroz", new BigDecimal("1250.00"), "Granos", "", 30));
        TIENDA.agregarProducto(new Producto("Leche", new BigDecimal("950.00"), "Lácteos", "", 25));
        TIENDA.agregarProducto(new Producto("Café", new BigDecimal("2800.00"), "Bebidas", "", 15));
        TIENDA.agregarProducto(new Producto("Pan", new BigDecimal("800.00"), "Panadería", "", 20));
    }

    private static String leerTexto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String valor = SCANNER.nextLine().trim();
            if (!valor.isBlank()) return valor;
            System.out.println("Este campo no puede quedar vacío.");
        }
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try { return Integer.parseInt(SCANNER.nextLine().trim()); }
            catch (NumberFormatException ex) { System.out.println("Ingrese un número entero válido."); }
        }
    }

    private static int leerEnteroPositivo(String mensaje) {
        while (true) {
            int valor = leerEntero(mensaje);
            if (valor > 0) return valor;
            System.out.println("El valor debe ser mayor que cero.");
        }
    }

    private static int leerEnteroRango(String mensaje, int minimo, int maximo) {
        while (true) {
            int valor = leerEntero(mensaje);
            if (valor >= minimo && valor <= maximo) return valor;
            System.out.printf("Ingrese un valor entre %d y %d.%n", minimo, maximo);
        }
    }

    private static BigDecimal leerDecimal(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                BigDecimal valor = new BigDecimal(SCANNER.nextLine().trim().replace(",", "."));
                if (valor.compareTo(BigDecimal.ZERO) >= 0) return valor;
                System.out.println("El precio no puede ser negativo.");
            } catch (NumberFormatException ex) {
                System.out.println("Ingrese un precio válido. Ejemplo: 1250.50");
            }
        }
    }

    private static boolean leerSiNo(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String respuesta = SCANNER.nextLine().trim().toLowerCase();
            if (respuesta.equals("s") || respuesta.equals("si") || respuesta.equals("sí")) return true;
            if (respuesta.equals("n") || respuesta.equals("no")) return false;
            System.out.println("Responda s o n.");
        }
    }
}
