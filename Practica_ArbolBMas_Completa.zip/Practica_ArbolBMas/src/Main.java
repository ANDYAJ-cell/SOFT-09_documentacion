import java.util.Scanner;

/**
 * Interfaz de consola para probar las operaciones del árbol B+.
 */
public class Main {
    private static final Scanner SCANNER = new Scanner(System.in);

    public static void main(String[] args) {
        int orden = leerEntero("Ingrese el orden del árbol B+ (mínimo 3): ", 3);
        ArbolBMas arbol = new ArbolBMas(orden);
        boolean continuar = true;

        while (continuar) {
            mostrarMenu();
            int opcion = leerEntero("Seleccione una opción: ", 0);
            switch (opcion) {
                case 1:
                    int clave = leerEntero("Clave entera: ", 0);
                    System.out.print("Dato asociado: ");
                    String dato = SCANNER.nextLine().trim();
                    arbol.insertar(clave, dato);
                    System.out.println("Registro insertado o actualizado correctamente.");
                    break;
                case 2:
                    int buscar = leerEntero("Clave que desea buscar: ", 0);
                    if (arbol.buscar(buscar)) {
                        System.out.println("Encontrada. Dato: " + arbol.obtener(buscar));
                    } else {
                        System.out.println("La clave no existe.");
                    }
                    break;
                case 3:
                    int eliminar = leerEntero("Clave que desea eliminar: ", 0);
                    System.out.println(arbol.eliminar(eliminar)
                            ? "Registro eliminado." : "No se encontró la clave.");
                    break;
                case 4:
                    arbol.imprimirArbol();
                    break;
                case 5:
                    int inicio = leerEntero("Clave inicial del recorrido: ", 0);
                    int cantidad = leerEntero("Cantidad de registros: ", 1);
                    arbol.recorrerRango(inicio, cantidad);
                    break;
                case 6:
                    int cantidadInicial = leerEntero("Cantidad de registros desde el menor: ", 1);
                    arbol.recorrerRango(cantidadInicial);
                    break;
                case 7:
                    arbol.imprimirRegistros();
                    break;
                case 0:
                    continuar = false;
                    System.out.println("Programa finalizado. ¡Gracias!");
                    break;
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
            }
            System.out.println();
        }
        SCANNER.close();
    }

    private static void mostrarMenu() {
        System.out.println("========== ÁRBOL B+ ==========");
        System.out.println("1. Insertar / actualizar registro");
        System.out.println("2. Buscar clave");
        System.out.println("3. Eliminar clave");
        System.out.println("4. Mostrar estructura del árbol");
        System.out.println("5. Recorrer rango desde una clave");
        System.out.println("6. Mostrar los primeros n registros");
        System.out.println("7. Mostrar todos los registros");
        System.out.println("0. Salir");
        System.out.println("==============================");
    }

    private static int leerEntero(String mensaje, int minimo) {
        while (true) {
            System.out.print(mensaje);
            String entrada = SCANNER.nextLine().trim();
            try {
                int valor = Integer.parseInt(entrada);
                if (valor < minimo) {
                    System.out.println("Ingrese un número mayor o igual que " + minimo + ".");
                } else {
                    return valor;
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Debe ingresar un número entero.");
            }
        }
    }
}
