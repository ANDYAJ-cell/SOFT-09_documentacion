import java.util.ArrayList;
import java.util.List;

/**
 * Nodo de un árbol B+. Las claves y los datos se almacenan únicamente
 * en las hojas; los nodos internos contienen claves separadoras e hijos.
 */
public class NodoArbolBMas {
    private boolean esHoja;
    private List<Integer> listaClaves;
    private List<NodoArbolBMas> listaHijos;
    private List<String> datos;
    private NodoArbolBMas siguiente;

    public NodoArbolBMas(boolean esHoja) {
        this.esHoja = esHoja;
        this.listaClaves = new ArrayList<>();
        this.listaHijos = new ArrayList<>();
        this.datos = esHoja ? new ArrayList<>() : null;
        this.siguiente = null;
    }

    public boolean esHoja() { return esHoja; }
    public List<Integer> getClaves() { return listaClaves; }
    public List<NodoArbolBMas> getHijos() { return listaHijos; }
    public List<String> getDatos() { return datos; }
    public NodoArbolBMas getSiguiente() { return siguiente; }

    public void setClaves(List<Integer> claves) { this.listaClaves = claves; }
    public void setHijos(List<NodoArbolBMas> hijos) { this.listaHijos = hijos; }
    public void setDatos(List<String> datos) { this.datos = datos; }
    public void setSiguiente(NodoArbolBMas siguiente) { this.siguiente = siguiente; }
}
