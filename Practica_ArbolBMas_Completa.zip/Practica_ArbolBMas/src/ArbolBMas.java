import java.util.ArrayList;
import java.util.List;

/**
 * Implementación de un árbol B+ para claves enteras y datos String.
 * El orden representa el máximo número de hijos de un nodo interno.
 */
public class ArbolBMas {
    // La consigna solicita que estos sean los únicos atributos del árbol.
    private final int orden;
    private NodoArbolBMas raiz;

    public ArbolBMas(int orden) {
        if (orden < 3) {
            throw new IllegalArgumentException("El orden del árbol debe ser al menos 3.");
        }
        this.orden = orden;
        this.raiz = new NodoArbolBMas(true);
    }

    /** Inserta una clave y asocia un dato descriptivo por defecto. */
    public void insertar(int clave) {
        insertar(clave, "Dato-" + clave);
    }

    /** Inserta una clave con su dato. Si ya existe, reemplaza su dato. */
    public void insertar(int clave, String dato) {
        if (dato == null) dato = "";
        NodoArbolBMas hoja = buscarHoja(clave);
        int posicion = posicionInsercion(hoja.getClaves(), clave);

        // No se permiten claves duplicadas: se actualiza el dato existente.
        if (posicion < hoja.getClaves().size() && hoja.getClaves().get(posicion) == clave) {
            hoja.getDatos().set(posicion, dato);
            return;
        }

        hoja.getClaves().add(posicion, clave);
        hoja.getDatos().add(posicion, dato);

        if (hoja.getClaves().size() > maxClaves()) {
            dividirRaizSiEsNecesario(hoja);
        } else {
            actualizarSeparadoresDesde(hoja);
        }
    }

    private void dividirRaizSiEsNecesario(NodoArbolBMas nodo) {
        if (nodo == raiz) {
            NodoArbolBMas nuevaRaiz = new NodoArbolBMas(false);
            nuevaRaiz.getHijos().add(raiz);
            dividirHijo(nuevaRaiz, 0);
            raiz = nuevaRaiz;
        } else {
            // La división no raíz se realiza recursivamente desde la ruta de inserción.
            dividirNodoNoRaiz(nodo);
        }
    }

    private void dividirNodoNoRaiz(NodoArbolBMas nodo) {
        Ruta ruta = buscarRuta(nodo);
        if (ruta == null) return;
        NodoArbolBMas padre = ruta.padre;
        int indice = ruta.indice;
        dividirHijo(padre, indice);
        if (padre.getClaves().size() > maxClaves()) {
            if (padre == raiz) {
                NodoArbolBMas nuevaRaiz = new NodoArbolBMas(false);
                nuevaRaiz.getHijos().add(raiz);
                dividirHijo(nuevaRaiz, 0);
                raiz = nuevaRaiz;
            } else {
                dividirNodoNoRaiz(padre);
            }
        } else {
            actualizarSeparadoresDesde(padre);
        }
    }

    /** Divide un hijo desbordado y coloca el nuevo hermano a su derecha. */
    private void dividirHijo(NodoArbolBMas padre, int indice) {
        NodoArbolBMas original = padre.getHijos().get(indice);
        NodoArbolBMas nuevo = new NodoArbolBMas(original.esHoja());
        if (original.esHoja()) {
            int corte = (original.getClaves().size() + 1) / 2;
            nuevo.setClaves(new ArrayList<>(original.getClaves().subList(corte, original.getClaves().size())));
            nuevo.setDatos(new ArrayList<>(original.getDatos().subList(corte, original.getDatos().size())));
            original.setClaves(new ArrayList<>(original.getClaves().subList(0, corte)));
            original.setDatos(new ArrayList<>(original.getDatos().subList(0, corte)));
            nuevo.setSiguiente(original.getSiguiente());
            original.setSiguiente(nuevo);
        } else {
            int corteHijos = (original.getHijos().size() + 1) / 2;
            nuevo.setHijos(new ArrayList<>(original.getHijos().subList(corteHijos, original.getHijos().size())));
            original.setHijos(new ArrayList<>(original.getHijos().subList(0, corteHijos)));
            reconstruirClavesInternas(original);
            reconstruirClavesInternas(nuevo);
        }
        padre.getHijos().add(indice + 1, nuevo);
        reconstruirClavesInternas(padre);
    }

    /** Busca una clave; solo las hojas contienen los registros reales. */
    public boolean buscar(int clave) {
        NodoArbolBMas hoja = buscarHoja(clave);
        int p = posicionInsercion(hoja.getClaves(), clave);
        return p < hoja.getClaves().size() && hoja.getClaves().get(p) == clave;
    }

    /** Devuelve el dato asociado o null si la clave no existe. */
    public String obtener(int clave) {
        NodoArbolBMas hoja = buscarHoja(clave);
        int p = posicionInsercion(hoja.getClaves(), clave);
        return p < hoja.getClaves().size() && hoja.getClaves().get(p) == clave
                ? hoja.getDatos().get(p) : null;
    }

    /**
     * Elimina una clave. Si un nodo queda por debajo del mínimo, toma claves/hijos
     * de un hermano o se fusiona con él. La raíz se ajusta al finalizar.
     */
    public boolean eliminar(int clave) {
        NodoArbolBMas hoja = buscarHoja(clave);
        int p = posicionInsercion(hoja.getClaves(), clave);
        if (p >= hoja.getClaves().size() || hoja.getClaves().get(p) != clave) {
            return false;
        }
        hoja.getClaves().remove(p);
        hoja.getDatos().remove(p);

        if (hoja == raiz) return true;

        Ruta ruta = buscarRuta(hoja);
        if (ruta != null) rebalancear(ruta.padre, ruta.indice);
        actualizarSeparadoresDesde(raiz);
        if (!raiz.esHoja() && raiz.getHijos().size() == 1) {
            raiz = raiz.getHijos().get(0);
        }
        if (!raiz.esHoja() && raiz.getHijos().isEmpty()) {
            raiz = new NodoArbolBMas(true);
        }
        return true;
    }

    private void rebalancear(NodoArbolBMas padre, int indice) {
        NodoArbolBMas nodo = padre.getHijos().get(indice);
        if (cumpleMinimo(nodo)) {
            reconstruirClavesInternas(padre);
            if (padre != raiz) {
                Ruta r = buscarRuta(padre);
                if (r != null) rebalancear(r.padre, r.indice);
            }
            return;
        }

        NodoArbolBMas izquierdo = indice > 0 ? padre.getHijos().get(indice - 1) : null;
        NodoArbolBMas derecho = indice + 1 < padre.getHijos().size()
                ? padre.getHijos().get(indice + 1) : null;

        if (izquierdo != null && cantidadMovible(izquierdo) > minimoElementos(nodo)) {
            prestarDesdeIzquierdo(izquierdo, nodo);
        } else if (derecho != null && cantidadMovible(derecho) > minimoElementos(nodo)) {
            prestarDesdeDerecho(nodo, derecho);
        } else if (izquierdo != null) {
            fusionar(izquierdo, nodo);
            padre.getHijos().remove(indice);
        } else if (derecho != null) {
            fusionar(nodo, derecho);
            padre.getHijos().remove(indice + 1);
        }

        reconstruirClavesInternas(padre);
        if (padre == raiz) {
            if (padre.getHijos().size() == 1) raiz = padre.getHijos().get(0);
        } else if (!cumpleMinimo(padre)) {
            Ruta r = buscarRuta(padre);
            if (r != null) rebalancear(r.padre, r.indice);
        } else {
            actualizarSeparadoresDesde(padre);
        }
    }

    private void prestarDesdeIzquierdo(NodoArbolBMas izq, NodoArbolBMas nodo) {
        if (nodo.esHoja()) {
            int ultimo = izq.getClaves().size() - 1;
            nodo.getClaves().add(0, izq.getClaves().remove(ultimo));
            nodo.getDatos().add(0, izq.getDatos().remove(ultimo));
        } else {
            nodo.getHijos().add(0, izq.getHijos().remove(izq.getHijos().size() - 1));
            reconstruirClavesInternas(izq);
            reconstruirClavesInternas(nodo);
        }
    }

    private void prestarDesdeDerecho(NodoArbolBMas nodo, NodoArbolBMas der) {
        if (nodo.esHoja()) {
            nodo.getClaves().add(der.getClaves().remove(0));
            nodo.getDatos().add(der.getDatos().remove(0));
        } else {
            nodo.getHijos().add(der.getHijos().remove(0));
            reconstruirClavesInternas(nodo);
            reconstruirClavesInternas(der);
        }
    }

    private void fusionar(NodoArbolBMas izquierda, NodoArbolBMas derecha) {
        if (izquierda.esHoja()) {
            izquierda.getClaves().addAll(derecha.getClaves());
            izquierda.getDatos().addAll(derecha.getDatos());
            izquierda.setSiguiente(derecha.getSiguiente());
        } else {
            izquierda.getHijos().addAll(derecha.getHijos());
            reconstruirClavesInternas(izquierda);
        }
    }

    private boolean cumpleMinimo(NodoArbolBMas nodo) {
        return cantidadMovible(nodo) >= minimoElementos(nodo);
    }

    private int cantidadMovible(NodoArbolBMas nodo) {
        return nodo.esHoja() ? nodo.getClaves().size() : nodo.getHijos().size();
    }

    private int minimoElementos(NodoArbolBMas nodo) {
        if (nodo.esHoja()) return (maxClaves() + 1) / 2;
        return (orden + 1) / 2;
    }

    /** Imprime las claves de cada nivel de forma jerárquica. */
    public void imprimirArbol() {
        imprimirNodo(raiz, "", true);
    }

    private void imprimirNodo(NodoArbolBMas nodo, String prefijo, boolean ultimo) {
        System.out.println(prefijo + "+- " + (nodo.esHoja() ? "Hoja " : "Interno ")
                + nodo.getClaves());
        String nuevoPrefijo = prefijo + (ultimo ? "   " : "|  ");
        for (int i = 0; i < nodo.getHijos().size(); i++) {
            imprimirNodo(nodo.getHijos().get(i), nuevoPrefijo, i == nodo.getHijos().size() - 1);
        }
    }

    /** Imprime los primeros n registros, comenzando por la clave menor. */
    public void recorrerRango(int n) {
        recorrerDesdePrimeraHoja(n);
    }

    /** Busca la clave inicial e imprime hasta n registros desde esa posición. */
    public void recorrerRango(int claveInicial, int n) {
        if (n <= 0) {
            System.out.println("La cantidad debe ser mayor que cero.");
            return;
        }
        NodoArbolBMas hoja = buscarHoja(claveInicial);
        int indice = posicionInsercion(hoja.getClaves(), claveInicial);
        imprimirSiguientes(hoja, indice, n);
    }

    private void recorrerDesdePrimeraHoja(int n) {
        if (n <= 0) {
            System.out.println("La cantidad debe ser mayor que cero.");
            return;
        }
        NodoArbolBMas hoja = raiz;
        while (!hoja.esHoja()) hoja = hoja.getHijos().get(0);
        imprimirSiguientes(hoja, 0, n);
    }

    private void imprimirSiguientes(NodoArbolBMas hoja, int indice, int n) {
        int impresos = 0;
        while (hoja != null && impresos < n) {
            while (indice < hoja.getClaves().size() && impresos < n) {
                System.out.println(hoja.getClaves().get(indice) + " -> " + hoja.getDatos().get(indice));
                indice++;
                impresos++;
            }
            hoja = hoja.getSiguiente();
            indice = 0;
        }
        if (impresos == 0) System.out.println("No hay registros desde la clave indicada.");
    }

    /** Muestra todos los registros en orden usando los enlaces entre hojas. */
    public void imprimirRegistros() {
        recorrerRango(Integer.MAX_VALUE);
    }

    private NodoArbolBMas buscarHoja(int clave) {
        NodoArbolBMas actual = raiz;
        while (!actual.esHoja()) {
            int i = 0;
            while (i < actual.getClaves().size() && clave >= actual.getClaves().get(i)) i++;
            actual = actual.getHijos().get(i);
        }
        return actual;
    }

    private int posicionInsercion(List<Integer> claves, int clave) {
        int i = 0;
        while (i < claves.size() && claves.get(i) < clave) i++;
        return i;
    }

    private int maxClaves() { return orden - 1; }

    /** Las separadoras se reconstruyen con la primera clave de cada hijo derecho. */
    private void reconstruirClavesInternas(NodoArbolBMas nodo) {
        if (nodo.esHoja()) return;
        List<Integer> separadoras = new ArrayList<>();
        for (int i = 1; i < nodo.getHijos().size(); i++) {
            separadoras.add(primeraClave(nodo.getHijos().get(i)));
        }
        nodo.setClaves(separadoras);
    }

    private int primeraClave(NodoArbolBMas nodo) {
        while (!nodo.esHoja()) nodo = nodo.getHijos().get(0);
        if (nodo.getClaves().isEmpty()) return Integer.MIN_VALUE;
        return nodo.getClaves().get(0);
    }

    private void actualizarSeparadoresDesde(NodoArbolBMas nodo) {
        if (nodo == null || nodo.esHoja()) return;
        for (NodoArbolBMas hijo : nodo.getHijos()) actualizarSeparadoresDesde(hijo);
        reconstruirClavesInternas(nodo);
    }

    private Ruta buscarRuta(NodoArbolBMas objetivo) {
        return buscarRutaRec(raiz, objetivo);
    }

    private Ruta buscarRutaRec(NodoArbolBMas actual, NodoArbolBMas objetivo) {
        if (actual.esHoja()) return null;
        for (int i = 0; i < actual.getHijos().size(); i++) {
            NodoArbolBMas hijo = actual.getHijos().get(i);
            if (hijo == objetivo) return new Ruta(actual, i);
            Ruta encontrada = buscarRutaRec(hijo, objetivo);
            if (encontrada != null) return encontrada;
        }
        return null;
    }

    private static class Ruta {
        private final NodoArbolBMas padre;
        private final int indice;
        private Ruta(NodoArbolBMas padre, int indice) {
            this.padre = padre;
            this.indice = indice;
        }
    }
}
