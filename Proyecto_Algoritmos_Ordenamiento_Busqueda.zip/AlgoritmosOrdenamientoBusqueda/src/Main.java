import java.util.Scanner;

/**
 * Proyecto: Algoritmos de ordenamiento y búsqueda
 * Curso: SOFT-10 Estructura de Datos
 *
 * El programa permite ingresar palabras en un arreglo de tamaño definido
 * por el usuario, ordenarlas mediante cinco algoritmos y buscar una palabra
 * utilizando búsqueda binaria.
 */
public class Main {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("==============================================");
        System.out.println("   ALGORITMOS DE ORDENAMIENTO Y BUSQUEDA");
        System.out.println("==============================================");

        int cantidad = leerEnteroPositivo("Ingrese la cantidad de palabras: ");
        String[] palabras = new String[cantidad];

        // Se llena el arreglo con las palabras indicadas por el usuario.
        for (int i = 0; i < palabras.length; i++) {
            palabras[i] = leerPalabra("Ingrese la palabra " + (i + 1) + ": ");
        }

        System.out.println("\nArreglo original:");
        mostrarArreglo(palabras);

        boolean ordenado = false;

        // El menú permite seleccionar el algoritmo de ordenamiento.
        while (!ordenado) {
            mostrarMenuOrdenamiento();
            int opcion = leerEnteroEnRango("Seleccione una opción: ", 1, 6);

            switch (opcion) {
                case 1:
                    selectionSort(palabras);
                    System.out.println("\nSe aplicó el método de selección.");
                    ordenado = true;
                    break;
                case 2:
                    insertionSort(palabras);
                    System.out.println("\nSe aplicó el método de inserción.");
                    ordenado = true;
                    break;
                case 3:
                    bubbleSort(palabras);
                    System.out.println("\nSe aplicó el método burbuja.");
                    ordenado = true;
                    break;
                case 4:
                    mergeSort(palabras, 0, palabras.length - 1);
                    System.out.println("\nSe aplicó el método mezcla (Merge Sort).");
                    ordenado = true;
                    break;
                case 5:
                    quickSort(palabras, 0, palabras.length - 1);
                    System.out.println("\nSe aplicó el método rápido (Quick Sort).");
                    ordenado = true;
                    break;
                case 6:
                    System.out.println("\nSeleccione uno de los algoritmos para continuar.");
                    break;
                default:
                    // La validación del rango evita llegar a este caso.
                    System.out.println("Opción no válida.");
            }
        }

        System.out.println("\nArreglo ordenado alfabéticamente:");
        mostrarArreglo(palabras);

        // La búsqueda binaria requiere que el arreglo esté previamente ordenado.
        boolean continuarBuscando = true;
        while (continuarBuscando) {
            String buscada = leerPalabra("\nIngrese la palabra que desea buscar: ");
            int posicion = binarySearch(palabras, buscada);

            if (posicion >= 0) {
                System.out.println("La palabra \"" + buscada
                        + "\" fue encontrada en la posición " + (posicion + 1) + ".");
            } else {
                System.out.println("La palabra \"" + buscada + "\" no se encuentra en el arreglo.");
            }

            System.out.print("¿Desea realizar otra búsqueda? (S/N): ");
            String respuesta = scanner.nextLine().trim();
            continuarBuscando = respuesta.equalsIgnoreCase("S");
        }

        System.out.println("\nPrograma finalizado. ¡Gracias!");
        scanner.close();
    }

    // Lee un entero positivo y vuelve a solicitarlo si el dato no es válido.
    private static int leerEnteroPositivo(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String entrada = scanner.nextLine().trim();
            try {
                int numero = Integer.parseInt(entrada);
                if (numero > 0) {
                    return numero;
                }
                System.out.println("Debe ingresar un número mayor que cero.");
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Ingrese un número entero.");
            }
        }
    }

    // Lee una opción entera dentro de un rango permitido.
    private static int leerEnteroEnRango(String mensaje, int minimo, int maximo) {
        while (true) {
            System.out.print(mensaje);
            String entrada = scanner.nextLine().trim();
            try {
                int numero = Integer.parseInt(entrada);
                if (numero >= minimo && numero <= maximo) {
                    return numero;
                }
                System.out.println("Seleccione un número entre " + minimo + " y " + maximo + ".");
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Ingrese un número entero.");
            }
        }
    }

    // Evita almacenar palabras vacías.
    private static String leerPalabra(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String palabra = scanner.nextLine().trim();
            if (!palabra.isEmpty()) {
                return palabra;
            }
            System.out.println("La palabra no puede estar vacía.");
        }
    }

    private static void mostrarMenuOrdenamiento() {
        System.out.println("\n--------------- MENU ---------------");
        System.out.println("1. Ordenamiento por selección");
        System.out.println("2. Ordenamiento por inserción");
        System.out.println("3. Ordenamiento burbuja");
        System.out.println("4. Ordenamiento por mezcla (Merge Sort)");
        System.out.println("5. Ordenamiento rápido (Quick Sort)");
        System.out.println("6. Mostrar menú nuevamente");
        System.out.println("------------------------------------");
    }

    // Muestra todos los elementos del arreglo en una sola línea.
    private static void mostrarArreglo(String[] arreglo) {
        System.out.print("[");
        for (int i = 0; i < arreglo.length; i++) {
            System.out.print(arreglo[i]);
            if (i < arreglo.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }

    // Compara palabras sin distinguir entre mayúsculas y minúsculas.
    private static int comparar(String primera, String segunda) {
        return primera.compareToIgnoreCase(segunda);
    }

    /*
     * SELECCIÓN (Selection Sort)
     * Busca el elemento menor de la parte no ordenada y lo coloca
     * en la siguiente posición disponible.
     * Complejidad temporal: O(n^2) en mejor, promedio y peor caso.
     * Complejidad espacial: O(1).
     */
    private static void selectionSort(String[] arreglo) {
        for (int i = 0; i < arreglo.length - 1; i++) {
            int indiceMenor = i;

            // Se localiza la posición del menor elemento restante.
            for (int j = i + 1; j < arreglo.length; j++) {
                if (comparar(arreglo[j], arreglo[indiceMenor]) < 0) {
                    indiceMenor = j;
                }
            }

            // Se intercambia el menor elemento con la posición actual.
            String temporal = arreglo[i];
            arreglo[i] = arreglo[indiceMenor];
            arreglo[indiceMenor] = temporal;
        }
    }

    /*
     * INSERCIÓN (Insertion Sort)
     * Toma cada elemento y lo inserta en la posición correcta
     * dentro de la sección que ya está ordenada.
     * Complejidad temporal: O(n) en el mejor caso y O(n^2)
     * en el promedio y peor caso.
     * Complejidad espacial: O(1).
     */
    private static void insertionSort(String[] arreglo) {
        for (int i = 1; i < arreglo.length; i++) {
            String actual = arreglo[i];
            int j = i - 1;

            // Se desplazan a la derecha los elementos mayores que el actual.
            while (j >= 0 && comparar(arreglo[j], actual) > 0) {
                arreglo[j + 1] = arreglo[j];
                j--;
            }

            // Se inserta el elemento en el espacio que quedó libre.
            arreglo[j + 1] = actual;
        }
    }

    /*
     * BURBUJA (Bubble Sort)
     * Compara elementos vecinos e intercambia sus posiciones cuando
     * están en el orden incorrecto. Se detiene antes si no hubo cambios.
     * Complejidad temporal: O(n) en el mejor caso y O(n^2)
     * en el promedio y peor caso.
     * Complejidad espacial: O(1).
     */
    private static void bubbleSort(String[] arreglo) {
        for (int i = 0; i < arreglo.length - 1; i++) {
            boolean huboIntercambio = false;

            // Cada recorrido lleva el mayor elemento pendiente al final.
            for (int j = 0; j < arreglo.length - 1 - i; j++) {
                if (comparar(arreglo[j], arreglo[j + 1]) > 0) {
                    String temporal = arreglo[j];
                    arreglo[j] = arreglo[j + 1];
                    arreglo[j + 1] = temporal;
                    huboIntercambio = true;
                }
            }

            // Si no hubo intercambios, el arreglo ya está ordenado.
            if (!huboIntercambio) {
                break;
            }
        }
    }

    /*
     * MEZCLA (Merge Sort)
     * Divide el arreglo en mitades, ordena cada mitad recursivamente
     * y luego combina ambas mitades en orden.
     * Complejidad temporal: O(n log n) en mejor, promedio y peor caso.
     * Complejidad espacial: O(n), por el arreglo auxiliar.
     */
    private static void mergeSort(String[] arreglo, int inicio, int fin) {
        if (inicio < fin) {
            // Se calcula el punto medio para dividir el arreglo.
            int medio = inicio + (fin - inicio) / 2;

            // Se ordena recursivamente la mitad izquierda y la derecha.
            mergeSort(arreglo, inicio, medio);
            mergeSort(arreglo, medio + 1, fin);

            // Se combinan las dos mitades ya ordenadas.
            merge(arreglo, inicio, medio, fin);
        }
    }

    private static void merge(String[] arreglo, int inicio, int medio, int fin) {
        int cantidadIzquierda = medio - inicio + 1;
        int cantidadDerecha = fin - medio;

        String[] izquierda = new String[cantidadIzquierda];
        String[] derecha = new String[cantidadDerecha];

        // Se copian los elementos de cada mitad a arreglos auxiliares.
        for (int i = 0; i < cantidadIzquierda; i++) {
            izquierda[i] = arreglo[inicio + i];
        }
        for (int j = 0; j < cantidadDerecha; j++) {
            derecha[j] = arreglo[medio + 1 + j];
        }

        int i = 0;
        int j = 0;
        int k = inicio;

        // Se comparan los primeros elementos disponibles de ambas mitades.
        while (i < cantidadIzquierda && j < cantidadDerecha) {
            if (comparar(izquierda[i], derecha[j]) <= 0) {
                arreglo[k] = izquierda[i];
                i++;
            } else {
                arreglo[k] = derecha[j];
                j++;
            }
            k++;
        }

        // Se copian los elementos que hayan quedado en la mitad izquierda.
        while (i < cantidadIzquierda) {
            arreglo[k] = izquierda[i];
            i++;
            k++;
        }

        // Se copian los elementos que hayan quedado en la mitad derecha.
        while (j < cantidadDerecha) {
            arreglo[k] = derecha[j];
            j++;
            k++;
        }
    }

    /*
     * RÁPIDO (Quick Sort)
     * Selecciona un pivote y reorganiza los elementos: los menores
     * quedan a su izquierda y los mayores a su derecha. Luego ordena
     * recursivamente las dos particiones.
     * Complejidad temporal: O(n log n) en promedio y mejor caso;
     * O(n^2) en el peor caso.
     * Complejidad espacial: O(log n) promedio por la recursión;
     * O(n) en el peor caso.
     */
    private static void quickSort(String[] arreglo, int inicio, int fin) {
        if (inicio < fin) {
            // La partición devuelve la posición definitiva del pivote.
            int posicionPivote = partition(arreglo, inicio, fin);

            // Se ordenan las secciones que quedan a ambos lados del pivote.
            quickSort(arreglo, inicio, posicionPivote - 1);
            quickSort(arreglo, posicionPivote + 1, fin);
        }
    }

    private static int partition(String[] arreglo, int inicio, int fin) {
        // Se utiliza el último elemento como pivote.
        String pivote = arreglo[fin];
        int indiceMenores = inicio - 1;

        // Se colocan antes del pivote los elementos menores o iguales.
        for (int j = inicio; j < fin; j++) {
            if (comparar(arreglo[j], pivote) <= 0) {
                indiceMenores++;

                String temporal = arreglo[indiceMenores];
                arreglo[indiceMenores] = arreglo[j];
                arreglo[j] = temporal;
            }
        }

        // Se coloca el pivote entre los elementos menores y mayores.
        String temporal = arreglo[indiceMenores + 1];
        arreglo[indiceMenores + 1] = arreglo[fin];
        arreglo[fin] = temporal;

        return indiceMenores + 1;
    }

    /*
     * BÚSQUEDA BINARIA
     * Compara la palabra buscada con el elemento central del arreglo.
     * Si no coincide, continúa únicamente en la mitad donde podría estar.
     * Complejidad temporal: O(log n).
     * Complejidad espacial: O(1), porque es una implementación iterativa.
     * Requisito: el arreglo debe estar ordenado previamente.
     *
     * Retorna el índice donde se encontró la palabra o -1 si no existe.
     */
    private static int binarySearch(String[] arreglo, String buscada) {
        int izquierda = 0;
        int derecha = arreglo.length - 1;

        while (izquierda <= derecha) {
            // Se calcula el punto medio evitando sumar directamente ambos límites.
            int medio = izquierda + (derecha - izquierda) / 2;
            int resultado = comparar(arreglo[medio], buscada);

            if (resultado == 0) {
                // La palabra coincide con el elemento central.
                return medio;
            } else if (resultado < 0) {
                // La palabra buscada, si existe, está en la mitad derecha.
                izquierda = medio + 1;
            } else {
                // La palabra buscada, si existe, está en la mitad izquierda.
                derecha = medio - 1;
            }
        }

        // Si los límites se cruzan, la palabra no está en el arreglo.
        return -1;
    }
}
