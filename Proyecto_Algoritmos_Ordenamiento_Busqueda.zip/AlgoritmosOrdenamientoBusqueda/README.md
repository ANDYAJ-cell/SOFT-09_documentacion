# Algoritmos de ordenamiento y búsqueda

Proyecto en Java para SOFT-10 Estructura de Datos.

## Requisitos
- Java JDK 8 o superior.
- IntelliJ IDEA (opcional).

## Archivos
- `src/Main.java`: programa principal y subrutinas de ordenamiento y búsqueda.
- `ENLACE_GITHUB.txt`: espacio para colocar el enlace del repositorio después de publicarlo.

## Cómo ejecutar
1. Abra IntelliJ IDEA y seleccione **Open**.
2. Seleccione la carpeta `AlgoritmosOrdenamientoBusqueda`.
3. Abra `src/Main.java`.
4. Ejecute el método `main`.

También puede compilar y ejecutar desde una terminal ubicada en la carpeta del proyecto:

```bash
javac -encoding UTF-8 src/Main.java
java -cp src Main
```

## Funcionamiento
1. El usuario indica cuántas palabras desea almacenar.
2. Ingresa las palabras.
3. Selecciona uno de los cinco métodos de ordenamiento.
4. El programa muestra el arreglo ordenado.
5. El usuario puede realizar búsquedas binarias.

Las comparaciones alfabéticas no distinguen entre mayúsculas y minúsculas.

## Complejidades temporales

| Algoritmo | Mejor caso | Promedio | Peor caso |
|---|---:|---:|---:|
| Selección | O(n²) | O(n²) | O(n²) |
| Inserción | O(n) | O(n²) | O(n²) |
| Burbuja optimizada | O(n) | O(n²) | O(n²) |
| Mezcla (Merge Sort) | O(n log n) | O(n log n) | O(n log n) |
| Rápido (Quick Sort) | O(n log n) | O(n log n) | O(n²) |
| Búsqueda binaria | O(1) | O(log n) | O(log n) |

`n` representa la cantidad de palabras del arreglo. La búsqueda binaria se ejecuta después del ordenamiento porque necesita que los elementos estén ordenados.

## Pruebas recomendadas
- Probar con una sola palabra.
- Probar con varias palabras desordenadas.
- Probar con palabras repetidas.
- Probar búsquedas de palabras existentes y no existentes.
- Probar palabras con combinaciones de mayúsculas y minúsculas.
